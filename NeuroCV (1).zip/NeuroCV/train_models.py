from pathlib import Path
from neurocv.training import train_all
if __name__=="__main__": train_all(Path(__file__).resolve().parent); print("Models and evaluation saved.")
