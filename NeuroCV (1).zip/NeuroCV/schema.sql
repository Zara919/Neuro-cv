CREATE TABLE interview_questions (id INTEGER PRIMARY KEY, career TEXT NOT NULL, question TEXT NOT NULL, UNIQUE(career, question));
CREATE TABLE learning_resources (skill TEXT PRIMARY KEY, stage TEXT NOT NULL, resource TEXT NOT NULL);
CREATE TABLE analyses (id INTEGER PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP, predicted_career TEXT, resume_score INTEGER, extracted_skills TEXT);

