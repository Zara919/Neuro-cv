# NeuroCV

An offline, multi-page AI career guidance and ATS-friendly resume system for a BS Artificial Intelligence semester project.

## Pages

- Dashboard: overview and navigation
- Analyze CV: NLP extraction, top-three careers, skill gap, score, KNN projects, interview questions and roadmap
- ATS Builder: converts PDF/text into a standard-heading, single-column resume and downloads it as universal plain text
- Model Evaluation: accuracy table, three-fold cross-validation, macro precision/recall/F1 and confusion matrix
- AI Topics: viva explanations for NLP, TF-IDF, Random Forest, Cosine Similarity, KNN and cross-validation
- About: project purpose, architecture, stack, ethics and limitations

## Run

```powershell
cd "path\to\NeuroCV"
python -m pip install -r requirements.txt
python train_models.py
python app.py
```

Open `http://127.0.0.1:5000`. Missing models are trained automatically on first launch.

## Important ATS Note

NeuroCV improves parser readability through standard section names, plain text, skill keywords and a single-column structure. No software can truthfully guarantee that a resume is "ATS approved" because employers use different parsers, scoring rules and job descriptions. Users must review extracted content before applying.

## Offline AI

No OpenAI, Gemini, Hugging Face or external APIs are used. Random Forest career prediction and KNN recommendations are trained from the local CSV datasets. SQLite stores local questions, resources and non-sensitive analysis summaries.
