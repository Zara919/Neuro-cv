import json,joblib,numpy as np,pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .database import connect
from .nlp import parse_resume

class NeuroCVService:
    def __init__(self,base):
        self.base=base; self.db_path=base/"instance"/"neurocv.db"; self.careers=pd.read_csv(base/"datasets"/"careers.csv"); self.careers["skill_list"]=self.careers.required_skills.apply(lambda x:x.split(";")); self.vocabulary=sorted({x for row in self.careers.skill_list for x in row}); self.model=joblib.load(base/"models"/"career_model.joblib"); self.projects=joblib.load(base/"models"/"project_knn.joblib")
    def analyze(self,text):
        parsed=parse_resume(text,self.vocabulary); skilltext=" ".join(parsed["skills"]) or "general problem solving"; probs=self.model.predict_proba([skilltext])[0]; labels=self.model.classes_; top=np.argsort(probs)[::-1][:3]; predictions=[{"career":labels[i],"confidence":round(float(probs[i])*100,1)} for i in top]; career=predictions[0]["career"]
        required=self.careers.loc[self.careers.career==career,"skill_list"].iloc[0]; a,b=set(parsed["skills"]),set(required); vec=TfidfVectorizer(ngram_range=(1,2)).fit_transform([skilltext," ".join(required)]); compatibility=round(float(cosine_similarity(vec[0],vec[1])[0,0])*100,1); gap={"matched":sorted(a&b),"missing":sorted(b-a),"compatibility":compatibility}
        components={"Completeness":20 if parsed["education_detected"] and parsed["experience_detected"] else 10,"Relevant skills":min(30,len(a)*4),"Experience":20 if parsed["experience_years"]>=2 else 14 if parsed["experience_detected"] else 0,"Projects":15 if parsed["projects_detected"] else 0,"Career alignment":round(compatibility*.15)}; score={"total":min(100,int(sum(components.values()))),"components":components}
        query=self.projects["vectorizer"].transform([career+" "+skilltext]); dist,idx=self.projects["knn"].kneighbors(query,n_neighbors=3); projects=[{"title":self.projects["projects"].iloc[i].title,"level":self.projects["projects"].iloc[i].level,"description":self.projects["projects"].iloc[i].description,"match":round((1-float(d))*100,1)} for d,i in zip(dist[0],idx[0])]
        with connect(self.db_path) as db:
            questions=[r["question"] for r in db.execute("SELECT question FROM interview_questions WHERE career=?",(career,))]; resources={r["skill"]:r for r in db.execute("SELECT * FROM learning_resources")}; db.execute("INSERT INTO analyses(predicted_career,resume_score,extracted_skills) VALUES(?,?,?)",(career,score["total"],json.dumps(sorted(a))))
        roadmap={x:[] for x in ["Beginner","Intermediate","Advanced"]}
        for skill in gap["missing"]:
            row=resources.get(skill); stage=row["stage"] if row else "Intermediate"; roadmap[stage].append({"skill":skill,"resource":row["resource"] if row else f"Study {skill} and build a small offline exercise"})
        return {"parsed":parsed,"predictions":predictions,"primary_career":career,"gap":gap,"score":score,"projects":projects,"questions":questions,"roadmap":roadmap}

