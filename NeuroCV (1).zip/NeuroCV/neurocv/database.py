import sqlite3
QUESTIONS={
"Machine Learning Engineer":["Explain bias and variance.","How does Random Forest reduce overfitting?","How do you detect data leakage?"],
"Data Scientist":["How do you handle missing data?","When is correlation misleading?","How do you validate a hypothesis?"],
"NLP Engineer":["How does TF-IDF work?","Compare stemming and lemmatization.","How do you evaluate a classifier?"],
"Computer Vision Engineer":["What does a convolution learn?","Why augment images?","Explain IoU."],
"AI Researcher":["What is an ablation study?","What makes work reproducible?","Explain gradient descent."],
"Data Analyst":["How do you check data quality?","Choose a chart for distributions.","How do you communicate uncertainty?"],
"MLOps Engineer":["What is model drift?","Why use containers?","Design model monitoring."],
"Robotics Engineer":["Compare A-star and Dijkstra.","What is sensor fusion?","Explain PID control."]}
RESOURCES={"python":("Beginner","Python tutorial and practice"),"statistics":("Beginner","OpenIntro Statistics"),"sql":("Beginner","SQLite exercises"),"pandas":("Beginner","Pandas getting-started guide"),"numpy":("Beginner","NumPy quickstart"),"machine learning":("Intermediate","Scikit-learn model comparison lab"),"scikit-learn":("Intermediate","Scikit-learn examples"),"natural language processing":("Intermediate","NLTK Book"),"computer vision":("Intermediate","OpenCV tutorials"),"deep learning":("Advanced","Deep Learning textbook"),"docker":("Intermediate","Docker getting-started guide"),"kubernetes":("Advanced","Kubernetes concepts"),"research":("Advanced","Paper reproduction checklist"),"robotics":("Intermediate","ROS tutorials")}

def connect(path):
    db=sqlite3.connect(path); db.row_factory=sqlite3.Row; return db
def initialize(path):
    path.parent.mkdir(exist_ok=True)
    with connect(path) as db:
        db.executescript("CREATE TABLE IF NOT EXISTS interview_questions(id INTEGER PRIMARY KEY,career TEXT,question TEXT,UNIQUE(career,question)); CREATE TABLE IF NOT EXISTS learning_resources(skill TEXT PRIMARY KEY,stage TEXT,resource TEXT); CREATE TABLE IF NOT EXISTS analyses(id INTEGER PRIMARY KEY,created_at TEXT DEFAULT CURRENT_TIMESTAMP,predicted_career TEXT,resume_score INTEGER,extracted_skills TEXT);")
        db.executemany("INSERT OR IGNORE INTO interview_questions(career,question) VALUES(?,?)",[(c,q) for c,qs in QUESTIONS.items() for q in qs]); db.executemany("INSERT OR REPLACE INTO learning_resources VALUES(?,?,?)",[(s,*v) for s,v in RESOURCES.items()])

