"""NeuroCV offline AI package."""

