"""Offline resume NLP and ATS-friendly restructuring."""
import re
from PyPDF2 import PdfReader
from nltk.tokenize import RegexpTokenizer

HEADINGS = {"summary": "summary|profile|objective", "education": "education|academic background|qualifications", "experience": "experience|employment|work history|internships?", "projects": "projects?|portfolio|research", "skills": "skills?|technical skills|competencies"}

def extract_pdf_text(stream):
    return "\n".join(page.extract_text() or "" for page in PdfReader(stream).pages)

def normalize(text):
    return re.sub(r"\s+", " ", text.lower()).strip()

def tokenize(text):
    return RegexpTokenizer(r"[a-zA-Z][a-zA-Z+#./-]*").tokenize(text.lower())

def extract_sections(text):
    matches=[]
    for name, pattern in HEADINGS.items():
        matches += [(m.start(),m.end(),name) for m in re.finditer(rf"(?im)^\s*(?:{pattern})\s*:?[ \t]*$",text)]
    matches.sort(); sections={name:"" for name in HEADINGS}
    for i,(_,end,name) in enumerate(matches):
        sections[name]+=" "+text[end:(matches[i+1][0] if i+1<len(matches) else len(text))].strip()
    return {k:v.strip() for k,v in sections.items()}

def extract_skills(text,vocabulary):
    clean=normalize(text); aliases={"sklearn":"scikit-learn","nlp":"natural language processing","cnn":"convolutional neural networks"}; found=[]
    for skill in sorted(vocabulary,key=len,reverse=True):
        variants=[skill]+[a for a,c in aliases.items() if c==skill]
        if any(re.search(rf"(?<!\w){re.escape(v)}(?!\w)",clean) for v in variants): found.append(skill)
    return sorted(set(found))

def parse_resume(text,vocabulary):
    sections=extract_sections(text); years=[int(n) for n in re.findall(r"(?i)\b(\d{1,2})\+?\s+years?\b",text)]
    education=bool(sections["education"] or re.search(r"(?i)\b(?:bs|bsc|bachelor|ms|master|phd|degree|university)\b",text))
    return {"skills":extract_skills(text,vocabulary),"sections":sections,"education_detected":education,"experience_detected":bool(sections["experience"] or years),"experience_years":max(years,default=0),"projects_detected":bool(sections["projects"] or re.search(r"(?i)\bprojects?\b",text)),"token_count":len(tokenize(text))}

def ats_resume(text,parsed):
    """Create a single-column, text-first CV that common ATS parsers can read."""
    lines=[line.strip() for line in text.splitlines() if line.strip()]
    name=lines[0] if lines else "CANDIDATE NAME"
    contact=next((line for line in lines[1:6] if "@" in line or re.search(r"\d{3}.*\d{3}",line)),"Add phone | email | city | LinkedIn")
    s=parsed["sections"]
    summary=s["summary"] or "Motivated professional with relevant technical knowledge and project experience."
    def block(title,value): return f"\n{title.upper()}\n{value.strip() or 'Add relevant details here.'}\n"
    output=f"{name.upper()}\n{contact}\n"+block("Professional Summary",summary)+block("Skills",", ".join(parsed["skills"]))+block("Experience",s["experience"])+block("Projects",s["projects"])+block("Education",s["education"])
    return output.strip()+"\n"

