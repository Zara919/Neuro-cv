from pathlib import Path
import json, joblib, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score,precision_recall_fscore_support,confusion_matrix
from sklearn.model_selection import StratifiedKFold,cross_val_predict,cross_val_score
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import Pipeline

def pipeline():
    return Pipeline([("tfidf",TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True)),("classifier",RandomForestClassifier(n_estimators=300,random_state=42,class_weight="balanced"))])

def evaluate(data):
    model=pipeline(); cv=StratifiedKFold(n_splits=3,shuffle=True,random_state=42); pred=cross_val_predict(model,data.skills,data.career,cv=cv); scores=cross_val_score(model,data.skills,data.career,cv=cv,scoring="accuracy")
    p,r,f,_=precision_recall_fscore_support(data.career,pred,average="macro",zero_division=0); labels=sorted(data.career.unique())
    return {"folds":[round(float(v)*100,2) for v in scores],"accuracy":round(accuracy_score(data.career,pred)*100,2),"precision":round(float(p)*100,2),"recall":round(float(r)*100,2),"f1":round(float(f)*100,2),"labels":labels,"confusion_matrix":confusion_matrix(data.career,pred,labels=labels).tolist(),"samples":len(data)}

def train_all(base):
    models=base/"models"; models.mkdir(exist_ok=True); data=pd.read_csv(base/"datasets"/"training_profiles.csv"); model=pipeline().fit(data.skills,data.career); joblib.dump(model,models/"career_model.joblib"); (models/"evaluation.json").write_text(json.dumps(evaluate(data),indent=2))
    projects=pd.read_csv(base/"datasets"/"projects.csv"); text=projects.career+" "+projects.skills.str.replace(";"," ")+" "+projects.level; vec=TfidfVectorizer(ngram_range=(1,2)).fit(text); matrix=vec.transform(text); knn=NearestNeighbors(metric="cosine",algorithm="brute").fit(matrix); joblib.dump({"vectorizer":vec,"knn":knn,"projects":projects},models/"project_knn.joblib")

