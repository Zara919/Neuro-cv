document.addEventListener("DOMContentLoaded",()=>{const f=document.querySelector("#resume_file"),n=document.querySelector("#file-name");if(f)f.addEventListener("change",()=>n.textContent=f.files[0]?.name||"Choose a PDF");const s=document.querySelector("#sample-button");if(s)s.addEventListener("click",()=>document.querySelector("#resume_text").value=`Ayesha Khan | ayesha@example.com | 0300 1234567
BS Artificial Intelligence, National University, 2026

SKILLS
Python, pandas, NumPy, scikit-learn, machine learning, statistics, SQL, NLTK, data visualization, Git

EXPERIENCE
AI Intern with 1 year of experience preparing datasets and evaluating classification models.

PROJECTS
Built a Random Forest student predictor and an offline TF-IDF news classifier.

EDUCATION
BS Artificial Intelligence, expected 2026.`)});

