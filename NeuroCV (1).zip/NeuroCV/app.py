from pathlib import Path
import json
from flask import Flask,jsonify,render_template,request,Response
from PyPDF2.errors import PdfReadError
from neurocv.database import initialize
from neurocv.nlp import extract_pdf_text,parse_resume,ats_resume
from neurocv.training import train_all
from neurocv.service import NeuroCVService

BASE=Path(__file__).resolve().parent; app=Flask(__name__); app.config.update(MAX_CONTENT_LENGTH=5*1024*1024,SECRET_KEY="offline-neurocv")
initialize(BASE/"instance"/"neurocv.db")
if not (BASE/"models"/"career_model.joblib").exists(): train_all(BASE)
service=NeuroCVService(BASE)

def submitted_text():
    text=request.form.get("resume_text","").strip(); file=request.files.get("resume_file")
    if file and file.filename:
        if not file.filename.lower().endswith(".pdf"): raise ValueError("Only PDF uploads are supported.")
        text=extract_pdf_text(file.stream).strip()
    if len(text)<40: raise ValueError("Provide a readable resume of at least 40 characters.")
    return text

@app.get("/")
def dashboard(): return render_template("dashboard.html")
@app.get("/analyze")
def analyze_page(): return render_template("analyze.html")
@app.post("/analyze")
def analyze():
    try:return render_template("results.html",result=service.analyze(submitted_text()))
    except (ValueError,OSError,PdfReadError) as e:return render_template("analyze.html",error=str(e)),400
@app.get("/evaluation")
def evaluation(): return render_template("evaluation.html",metrics=json.loads((BASE/"models"/"evaluation.json").read_text()))
@app.get("/ats")
def ats_page(): return render_template("ats.html")
@app.post("/ats")
def ats_convert():
    try:
        text=submitted_text(); parsed=parse_resume(text,service.vocabulary); converted=ats_resume(text,parsed); return render_template("ats.html",converted=converted,parsed=parsed)
    except (ValueError,OSError,PdfReadError) as e:return render_template("ats.html",error=str(e)),400
@app.post("/download-resume")
def download_resume():
    content=request.form.get("content",""); return Response(content,mimetype="text/plain",headers={"Content-Disposition":"attachment; filename=NeuroCV_ATS_Resume.txt"})
@app.get("/topics")
def topics(): return render_template("topics.html")
@app.get("/about")
def about(): return render_template("about.html")
@app.get("/health")
def health():return {"status":"ok","mode":"offline"}
@app.post("/api/analyze")
def api():
    try:return jsonify(service.analyze(submitted_text()))
    except ValueError as e:return jsonify(error=str(e)),400
if __name__=="__main__":app.run(debug=True,host="127.0.0.1",port=5000)
