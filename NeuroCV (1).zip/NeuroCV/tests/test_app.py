from app import app
def test_pages():
    c=app.test_client()
    for path in ["/","/analyze","/ats","/evaluation","/topics","/about","/health"]: assert c.get(path).status_code==200
def test_analysis_and_ats():
    c=app.test_client(); text="BS Artificial Intelligence\nSKILLS\nPython pandas numpy machine learning statistics SQL scikit-learn\nEXPERIENCE\nOne year AI internship.\nPROJECTS\nBuilt a classification model and dashboard.\nEDUCATION\nBS AI University"
    assert c.post("/analyze",data={"resume_text":text}).status_code==200
    r=c.post("/ats",data={"resume_text":text}); assert r.status_code==200 and b"PROFESSIONAL SUMMARY" in r.data
def test_download():
    r=app.test_client().post("/download-resume",data={"content":"TEST RESUME"}); assert r.status_code==200 and "attachment" in r.headers["Content-Disposition"]

